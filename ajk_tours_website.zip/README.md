# Ajgaonkar Tours & Travels Website

This is the React + Tailwind (Next.js) website project for Ajgaonkar Tours & Travels.

## How to run locally
1. Install Node.js (>=16)
2. Run `npm install`
3. Run `npm run dev`

Deployed easily on Vercel.
